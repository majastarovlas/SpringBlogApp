package com.springapp.controller;

import com.springapp.entity.PostTag;
import com.springapp.service.posttag.IPostTagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class PostTagRESTController {

    @Autowired
    private IPostTagService postTagService;

    @GetMapping("/postTags")
    public List<PostTag> getPostTags() {
        return this.postTagService.getPostTags();
    }

    @GetMapping("/postTags/{postTagId}")
    public PostTag getPostTag(@PathVariable int postTagId) {

        PostTag thePostTag = this.postTagService.getPostTag(postTagId);

        if (thePostTag == null) {
            System.out.println("PostTag with id " + postTagId+  " not found.");
            return null;
        }

        return thePostTag;
    }

    @PostMapping("/postTags")
    public PostTag addPostTag(@RequestBody PostTag thePostTag) {

        thePostTag.setId(0);

        this.postTagService.savePostTag(thePostTag);

        return thePostTag;
    }

    @PutMapping("/postTags")
    public PostTag updatePostTag(@RequestBody PostTag thePostTag) {

        this.postTagService.savePostTag(thePostTag);

        return thePostTag;
    }

    @DeleteMapping("/postTags/{postTagId}")
    public void deletePostTag(@PathVariable int postTagId) {

        PostTag thePostTag = this.postTagService.getPostTag(postTagId);

        if (thePostTag == null) {
            System.out.println("PostTag with id " + postTagId +  " not found.");
            return; //null;
        }

        this.postTagService.deletePostTag(postTagId);

        //return "Deleted postTag with id: " + postTagId;
    }
}
