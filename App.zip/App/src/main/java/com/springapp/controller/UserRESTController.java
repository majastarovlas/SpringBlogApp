package com.springapp.controller;

import com.springapp.entity.User;
import com.springapp.service.user.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class UserRESTController {

    @Autowired
    private IUserService userService;

    @GetMapping("/users")
    public List<User> getUsers() {
        return this.userService.getUsers();
    }

    @GetMapping("/users/{userId}")
    public User getUser(@PathVariable int userId) {

        User theUser = this.userService.getUser(userId);

        if (theUser == null) {
            System.out.println("User with id " + userId+  " not found.");
            return null;
        }

        return theUser;
    }

    @PostMapping("/users")
    public User addUser(@RequestBody User theUser) {

        theUser.setId(0);

        this.userService.saveUser(theUser);

        return theUser;
    }

    @PutMapping("/users")
    public User updateUser(@RequestBody User theUser) {

        this.userService.saveUser(theUser);

        return theUser;
    }

    @DeleteMapping("/users/{userId}")
    public void deleteUser(@PathVariable int userId) {

        User theUser = this.userService.getUser(userId);

        if (theUser == null) {
            System.out.println("User with id " + userId +  " not found.");
            return; //null;
        }

        this.userService.deleteUser(userId);

        //return "Deleted user with id: " + userId;
    }

    @GetMapping("/users/findUserByUsernameAndPassword")
    public User getByUsernameAndPassword(@RequestParam String username, @RequestParam String password) {

        User theUser = this.userService.getByUsernameAndPassword(username, password);

        if (theUser == null) {
            System.out.println("User with username " + username+  " and password " + password + " not found.");
            return null;
        }

        return theUser;
    }

    @GetMapping("/users/findUsersByRoleId")
    public List<User> getUsersByRoleId(@RequestParam int roleId) {

        List<User> users = this.userService.getUsersByRoleId(roleId);

        if (users == null || users.size() == 0) {
            System.out.println("Users with role id " + roleId +  " not found.");
            return null;
        }

        return users;
    }

    @GetMapping("/users/findUsersByRoleName")
    public List<User> getUsersByRoleName(@RequestParam String roleName) {

        List<User> users = this.userService.getUsersByRoleName(roleName);

        if (users == null || users.size() == 0) {
            System.out.println("Users with roleName " + roleName +  " not found.");
            return null;
        }

        return users;
    }
}
