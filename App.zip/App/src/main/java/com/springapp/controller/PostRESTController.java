package com.springapp.controller;

import com.springapp.entity.Post;
import com.springapp.service.post.IPostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class PostRESTController {

    @Autowired
    private IPostService postService;

    @GetMapping("/posts")
    public List<Post> getPosts() {
        return this.postService.getPosts();
    }

    @GetMapping("/posts/{postId}")
    public Post getPost(@PathVariable int postId) {

        Post thePost = this.postService.getPost(postId);

        if (thePost == null) {
            System.out.println("Post with id " + postId+  " not found.");
            return null;
        }

        return thePost;
    }

    @PostMapping("/posts")
    public Post addPost(@RequestBody Post thePost) {

        System.out.println(thePost);

        thePost.setId(0);

        this.postService.savePost(thePost);

        return thePost;
    }

    @PutMapping("/posts")
    public Post updatePost(@RequestBody Post thePost) {

        this.postService.savePost(thePost);

        return thePost;
    }

    @DeleteMapping("/posts/{postId}")
    public void deletePost(@PathVariable int postId) {

        Post thePost = this.postService.getPost(postId);

        if (thePost == null) {
            System.out.println("Post with id " + postId +  " not found.");
            return; //null;
        }

        this.postService.deletePost(postId);

        //return "Deleted post with id: " + postId;
    }

    @GetMapping("/posts/findPostsByUserId")
    public List<Post> getPostsByUserId(@RequestParam int userId) {

        List<Post> thePosts = this.postService.getPostsByUserId(userId);

        if (thePosts == null || thePosts.size() == 0) {
            System.out.println("Posts with userId " + userId +  " not found.");
            return null;
        }

        return thePosts;
    }

    @GetMapping("/posts/findPostsByTagName")
    public List<Post> getPostsByTagName(@RequestParam String tagName) {

        List<Post> thePosts = this.postService.getPostsByTagName(tagName);

        if (thePosts == null || thePosts.size() == 0) {
            System.out.println("Posts with tagName " + tagName +  " not found.");
            return null;
        }

        return thePosts;
    }

    @GetMapping("/posts/findPostsByCategoryName")
    public List<Post> getPostsByCategoryName(@RequestParam String categoryName) {

        List<Post> thePosts = this.postService.getPostsByCategoryName(categoryName);

        if (thePosts == null || thePosts.size() == 0) {
            System.out.println("Posts with categoryName " + categoryName +  " not found.");
            return null;
        }

        return thePosts;
    }
}
