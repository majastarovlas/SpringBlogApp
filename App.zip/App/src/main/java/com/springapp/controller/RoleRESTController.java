package com.springapp.controller;

import com.springapp.entity.Role;
import com.springapp.service.role.IRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class RoleRESTController {

    @Autowired
    private IRoleService roleService;

    @GetMapping("/roles")
    public List<Role> getRoles() {
        return this.roleService.getRoles();
    }

    @GetMapping("/roles/{roleId}")
    public Role getRole(@PathVariable int roleId) {

        Role theRole = this.roleService.getRole(roleId);

        if (theRole == null) {
            System.out.println("Role with id " + roleId+  " not found.");
            return null;
        }

        return theRole;
    }

    @PostMapping("/roles")
    public Role addRole(@RequestBody Role theRole) {

        theRole.setId(0);

        this.roleService.saveRole(theRole);

        return theRole;
    }

    @PutMapping("/roles")
    public Role updateRole(@RequestBody Role theRole) {

        this.roleService.saveRole(theRole);

        return theRole;
    }

    @DeleteMapping("/roles/{roleId}")
    public void deleteRole(@PathVariable int roleId) {

        Role theRole = this.roleService.getRole(roleId);

        if (theRole == null) {
            System.out.println("Role with id " + roleId +  " not found.");
            return; //null;
        }

        this.roleService.deleteRole(roleId);

        //return "Deleted role with id: " + roleId;
    }
}
