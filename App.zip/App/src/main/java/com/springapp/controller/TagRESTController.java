package com.springapp.controller;

import com.springapp.entity.Tag;
import com.springapp.service.tag.ITagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class TagRESTController {

    @Autowired
    private ITagService tagService;

    @GetMapping("/tags")
    public List<Tag> getTags() {
        return this.tagService.getTags();
    }

    @GetMapping("/tags/{tagId}")
    public Tag getTag(@PathVariable int tagId) {

        Tag theTag = this.tagService.getTag(tagId);

        if (theTag == null) {
            System.out.println("Tag with id " + tagId+  " not found.");
            return null;
        }

        return theTag;
    }

    @PostMapping("/tags")
    public Tag addTag(@RequestBody Tag theTag) {

        theTag.setId(0);

        this.tagService.saveTag(theTag);

        return theTag;
    }

    @PutMapping("/tags")
    public Tag updateTag(@RequestBody Tag theTag) {

        this.tagService.saveTag(theTag);

        return theTag;
    }

    @DeleteMapping("/tags/{tagId}")
    public void deleteTag(@PathVariable int tagId) {

        Tag theTag = this.tagService.getTag(tagId);

        if (theTag == null) {
            System.out.println("Tag with id " + tagId +  " not found.");
            return; //null;
        }

        this.tagService.deleteTag(tagId);

        //return "Deleted tag with id: " + tagId;
    }
}
