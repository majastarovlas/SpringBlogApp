package com.springapp.controller;

import com.springapp.entity.Category;
import com.springapp.service.category.ICategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class CategoryRESTController {

    @Autowired
    private ICategoryService categoryService;

    @GetMapping("/categories")
    public List<Category> getCategories() {
        return this.categoryService.getCategories();
    }

    @GetMapping("/categories/{categoryId}")
    public Category getCategory(@PathVariable int categoryId) {

        Category theCategory = this.categoryService.getCategory(categoryId);

        if (theCategory == null) {
            System.out.println("Category with id " + categoryId+  " not found.");
            return null;
        }

        return theCategory;
    }

    @PostMapping("/categories")
    public Category addCategory(@RequestBody Category theCategory) {

        theCategory.setId(0);

        this.categoryService.saveCategory(theCategory);

        return theCategory;
    }

    @PutMapping("/categories")
    public Category updateCategory(@RequestBody Category theCategory) {

        this.categoryService.saveCategory(theCategory);

        return theCategory;
    }

    @DeleteMapping("/categories/{categoryId}")
    public void deleteCategory(@PathVariable int categoryId) {

        Category theCategory = this.categoryService.getCategory(categoryId);

        if (theCategory == null) {
            System.out.println("Category with id " + categoryId +  " not found.");
            return; //null;
        }

        this.categoryService.deleteCategory(categoryId);

        //return "Deleted category with id: " + categoryId;
    }
}
