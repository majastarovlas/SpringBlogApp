package com.springapp.service.posttag;

import com.springapp.entity.PostTag;
import com.springapp.repository.posttag.IPostTagRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class PostTagServiceImpl implements IPostTagService {

    @Autowired
    private IPostTagRepository postTagRepository;

    @Override
    @Transactional
    public List<PostTag> getPostTags() {
        return this.postTagRepository.getPostTags();
    }

    @Override
    @Transactional
    public PostTag getPostTag(int theId) {
        return this.postTagRepository.getPostTag(theId);
    }

    @Override
    @Transactional
    public void savePostTag(PostTag thePostTag) {
        this.postTagRepository.savePostTag(thePostTag);
    }

    @Override
    @Transactional
    public void deletePostTag(int theId) {
        this.postTagRepository.deletePostTag(theId);
    }
}
