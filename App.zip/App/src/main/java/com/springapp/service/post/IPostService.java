package com.springapp.service.post;

import com.springapp.entity.Post;

import java.util.List;

public interface IPostService {

    List<Post> getPosts();

    Post getPost(int theId);

    void savePost(Post thePost);

    void deletePost(int theId);

    List<Post> getPostsByUserId(int userId);

    List<Post> getPostsByTagName(String tagName);

    List<Post> getPostsByCategoryName(String categoryName);
}
