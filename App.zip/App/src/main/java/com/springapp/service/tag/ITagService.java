package com.springapp.service.tag;

import com.springapp.entity.Tag;

import java.util.List;

public interface ITagService {

    List<Tag> getTags();

    Tag getTag(int theId);

    void saveTag(Tag theTag);

    void deleteTag(int theId);
}
