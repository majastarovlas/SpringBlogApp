package com.springapp.service.posttag;

import com.springapp.entity.PostTag;

import java.util.List;

public interface IPostTagService {

    List<PostTag> getPostTags();

    PostTag getPostTag(int theId);

    void savePostTag(PostTag thePostTag);

    void deletePostTag(int theId);
}
