package com.springapp.service.role;

import com.springapp.entity.Role;

import java.util.List;

public interface IRoleService {

    List<Role> getRoles();

    Role getRole(int theId);

    void saveRole(Role theRole);

    void deleteRole(int theId);
}
