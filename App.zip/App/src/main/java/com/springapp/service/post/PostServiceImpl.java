package com.springapp.service.post;

import com.springapp.entity.Post;
import com.springapp.repository.post.IPostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class PostServiceImpl implements IPostService {

    @Autowired
    private IPostRepository postRepository;

    @Override
    @Transactional
    public List<Post> getPosts() {
        return this.postRepository.getPosts();
    }

    @Override
    @Transactional
    public Post getPost(int theId) {
        return this.postRepository.getPost(theId);
    }

    @Override
    @Transactional
    public void savePost(Post thePost) {
        this.postRepository.savePost(thePost);
    }

    @Override
    @Transactional
    public void deletePost(int theId) { this.postRepository.deletePost(theId); }

    @Override
    @Transactional
    public List<Post> getPostsByUserId(int userId) {
        return this.postRepository.getPostsByUserId(userId);
    }

    @Override
    @Transactional
    public List<Post> getPostsByTagName(String tagName) {
        return this.postRepository.getPostsByTagName(tagName);
    }

    @Override
    @Transactional
    public List<Post> getPostsByCategoryName(String categoryName) {
        return this.postRepository.getPostsByCategoryName(categoryName);
    }
}
