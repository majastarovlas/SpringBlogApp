package com.springapp.service.user;

import com.springapp.entity.User;

import java.util.List;

public interface IUserService {

    List<User> getUsers();

    User getUser(int theId);

    void saveUser(User theUser);

    void deleteUser(int theId);

    User getByUsernameAndPassword(String username, String password);

    List<User> getUsersByRoleId(int theRoleId);

    List<User> getUsersByRoleName(String theRoleName);
}
