package com.springapp.service.user;

import com.springapp.entity.User;
import com.springapp.repository.user.IUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class UserServiceImpl implements IUserService {

    @Autowired
    private IUserRepository userRepository;

    @Override
    @Transactional
    public List<User> getUsers() {
        return this.userRepository.getUsers();
    }

    @Override
    @Transactional
    public User getUser(int theId) {
        return this.userRepository.getUser(theId);
    }

    @Override
    @Transactional
    public void saveUser(User theUser) {
        this.userRepository.saveUser(theUser);
    }

    @Override
    @Transactional
    public void deleteUser(int theId) {
        this.userRepository.deleteUser(theId);
    }

    @Override
    @Transactional
    public User getByUsernameAndPassword(String username, String password) {
        return this.userRepository.getByUsernameAndPassword(username, password);
    }

    @Override
    @Transactional
    public List<User> getUsersByRoleId(int theRoleId) {
        return this.userRepository.getUsersByRoleId(theRoleId);
    }

    @Override
    @Transactional
    public List<User> getUsersByRoleName(String theRoleName) {
        return this.userRepository.getUsersByRoleName(theRoleName);
    }
}
