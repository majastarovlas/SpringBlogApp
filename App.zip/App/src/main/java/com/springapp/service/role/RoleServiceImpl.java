package com.springapp.service.role;

import com.springapp.entity.Role;
import com.springapp.repository.role.IRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class RoleServiceImpl implements IRoleService {

    @Autowired
    private IRoleRepository roleRepository;

    @Override
    @Transactional
    public List<Role> getRoles() {
        return this.roleRepository.getRoles();
    }

    @Override
    @Transactional
    public Role getRole(int theId) {
        return this.roleRepository.getRole(theId);
    }

    @Override
    @Transactional
    public void saveRole(Role theRole) {
        this.roleRepository.saveRole(theRole);
    }

    @Override
    @Transactional
    public void deleteRole(int theId) { this.roleRepository.deleteRole(theId); }
}
