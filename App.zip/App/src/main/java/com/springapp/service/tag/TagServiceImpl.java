package com.springapp.service.tag;

import com.springapp.entity.Tag;
import com.springapp.entity.Tag;
import com.springapp.repository.tag.ITagRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class TagServiceImpl implements ITagService {

    @Autowired
    private ITagRepository tagRepository;

    @Override
    @Transactional
    public List<Tag> getTags() {
        return this.tagRepository.getTags();
    }

    @Override
    @Transactional
    public Tag getTag(int theId) {
        return this.tagRepository.getTag(theId);
    }

    @Override
    @Transactional
    public void saveTag(Tag theTag) {
        this.tagRepository.saveTag(theTag);
    }

    @Override
    @Transactional
    public void deleteTag(int theId) { this.tagRepository.deleteTag(theId); }
}
