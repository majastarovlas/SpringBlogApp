package com.springapp.service.category;

import com.springapp.entity.Category;

import java.util.List;

public interface ICategoryService {

    List<Category> getCategories();

    Category getCategory(int theId);

    void saveCategory(Category theCategory);

    void deleteCategory(int theId);
}
