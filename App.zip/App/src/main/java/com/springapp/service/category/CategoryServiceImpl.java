package com.springapp.service.category;

import com.springapp.entity.Category;
import com.springapp.repository.category.ICategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class CategoryServiceImpl implements ICategoryService {

    @Autowired
    private ICategoryRepository categoryRepository;

    @Override
    @Transactional
    public List<Category> getCategories() {
        return this.categoryRepository.getCategories();
    }

    @Override
    @Transactional
    public Category getCategory(int theId) {
        return this.categoryRepository.getCategory(theId);
    }

    @Override
    @Transactional
    public void saveCategory(Category theCategory) {
        this.categoryRepository.saveCategory(theCategory);
    }

    @Override
    @Transactional
    public void deleteCategory(int theId) { this.categoryRepository.deleteCategory(theId); }
}
