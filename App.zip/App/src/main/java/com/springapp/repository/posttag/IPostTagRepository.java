package com.springapp.repository.posttag;

import com.springapp.entity.PostTag;

import java.util.List;

public interface IPostTagRepository {

    List<PostTag> getPostTags();

    PostTag getPostTag(int theId);

    void savePostTag(PostTag thePostTag);

    void deletePostTag(int theId);
}
