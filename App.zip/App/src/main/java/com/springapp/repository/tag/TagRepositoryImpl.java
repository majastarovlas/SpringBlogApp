package com.springapp.repository.tag;

import com.springapp.entity.Tag;
import com.springapp.entity.Tag;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TagRepositoryImpl implements ITagRepository {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<Tag> getTags() {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query<Tag> theQuery = currentSession.createQuery("FROM Tag", Tag.class);

        List<Tag> tags = theQuery.getResultList();

        return tags;
    }

    @Override
    public Tag getTag(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Tag tag = currentSession.get(Tag.class, theId);

        return tag;
    }

    @Override
    public void saveTag(Tag theTag) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        currentSession.saveOrUpdate(theTag);
    }

    @Override
    public void deleteTag(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("DELETE FROM Tag WHERE id = :tagId");
        theQuery.setParameter("tagId", theId);

        theQuery.executeUpdate();
    }
}
