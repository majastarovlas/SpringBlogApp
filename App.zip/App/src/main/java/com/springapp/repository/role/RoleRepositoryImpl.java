package com.springapp.repository.role;

import com.springapp.entity.Role;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RoleRepositoryImpl implements IRoleRepository {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<Role> getRoles() {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query<Role> theQuery = currentSession.createQuery("FROM Role", Role.class);

        List<Role> roles = theQuery.getResultList();

        return roles;
    }

    @Override
    public Role getRole(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Role role = currentSession.get(Role.class, theId);

        return role;
    }

    @Override
    public void saveRole(Role theRole) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        currentSession.saveOrUpdate(theRole);
    }

    @Override
    public void deleteRole(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("DELETE FROM Role WHERE id = :roleId");
        theQuery.setParameter("roleId", theId);

        theQuery.executeUpdate();
    }
}
