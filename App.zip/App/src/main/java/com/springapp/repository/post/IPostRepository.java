package com.springapp.repository.post;

import com.springapp.entity.Post;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;


public interface IPostRepository {

    List<Post> getPosts();

    Post getPost(int theId);

    void savePost(Post thePost);

    void deletePost(int theId);

    List<Post> getPostsByUserId(int userId);

    List<Post> getPostsByTagName(String tagName);

    List<Post> getPostsByCategoryName(String categoryName);
}
