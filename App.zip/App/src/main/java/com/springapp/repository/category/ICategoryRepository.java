package com.springapp.repository.category;

import com.springapp.entity.Category;

import java.util.List;

public interface ICategoryRepository {

    List<Category> getCategories();

    Category getCategory(int theId);

    void saveCategory(Category theCategory);

    void deleteCategory(int theId);
}
