package com.springapp.repository.user;

import com.springapp.entity.Post;
import com.springapp.entity.User;

import java.util.List;

public interface IUserRepository {

    List<User> getUsers();

    User getUser(int theId);

    void saveUser(User theUser);

    void deleteUser(int theId);

    User getByUsernameAndPassword(String username, String password);

    List<User> getUsersByRoleId(int theRoleId);

    List<User> getUsersByRoleName(String theRoleName);
}
