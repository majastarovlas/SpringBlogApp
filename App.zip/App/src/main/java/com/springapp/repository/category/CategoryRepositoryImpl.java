package com.springapp.repository.category;

import com.springapp.entity.Category;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CategoryRepositoryImpl implements ICategoryRepository {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<Category> getCategories() {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query<Category> theQuery = currentSession.createQuery("FROM Category", Category.class);

        List<Category> categorys = theQuery.getResultList();

        return categorys;
    }

    @Override
    public Category getCategory(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Category category = currentSession.get(Category.class, theId);

        return category;
    }

    @Override
    public void saveCategory(Category theCategory) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        currentSession.saveOrUpdate(theCategory);
    }

    @Override
    public void deleteCategory(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("DELETE FROM Category WHERE id = :categoryId");
        theQuery.setParameter("categoryId", theId);

        theQuery.executeUpdate();
    }
}
