package com.springapp.repository.role;

import com.springapp.entity.Role;

import java.util.List;

public interface IRoleRepository {

    List<Role> getRoles();

    Role getRole(int theId);

    void saveRole(Role theRole);

    void deleteRole(int theId);
}
