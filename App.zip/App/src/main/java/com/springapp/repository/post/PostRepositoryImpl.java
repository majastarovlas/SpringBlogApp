package com.springapp.repository.post;

import com.springapp.entity.Post;
import com.springapp.entity.PostTag;
import com.springapp.entity.Tag;
import com.springapp.entity.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PostRepositoryImpl implements IPostRepository {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<Post> getPosts() {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query<Post> theQuery = currentSession.createQuery("FROM Post", Post.class);

        List<Post> posts = theQuery.getResultList();

        return posts;
    }

    @Override
    public Post getPost(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Post post = currentSession.get(Post.class, theId);

        return post;
    }

    @Override
    public void savePost(Post thePost) {

        System.out.println("PostRepository: " + thePost);

        Session currentSession = this.sessionFactory.getCurrentSession();

        currentSession.saveOrUpdate(thePost);
    }

    @Override
    public void deletePost(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("DELETE FROM Post WHERE id = :postId");
        theQuery.setParameter("postId", theId);

        theQuery.executeUpdate();
    }

    @Override
    public List<Post> getPostsByUserId(int userId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("FROM Post WHERE userId = :postUserId");
        theQuery.setParameter("postUserId", userId);

        List<Post> posts = theQuery.getResultList();

        return posts;
    }

    @Override
    public List<Post> getPostsByTagName(String tagName) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("SELECT pt.post FROM PostTag as pt WHERE pt.tag.tagName = :tagNameParam");
        theQuery.setParameter("tagNameParam", tagName);

        List<Post> thePosts = theQuery.getResultList();

        return thePosts;
    }

    @Override
    public List<Post> getPostsByCategoryName(String categoryName) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("FROM Post as post WHERE post.category.categoryName = :categoryNameParam");
        theQuery.setParameter("categoryNameParam", categoryName);

        List<Post> thePosts = theQuery.getResultList();

        return thePosts;
    }
}
