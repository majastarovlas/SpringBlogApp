package com.springapp.repository.user;

import com.springapp.entity.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserRepositoryImpl implements IUserRepository {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<User> getUsers() {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query<User> theQuery = currentSession.createQuery("FROM User", User.class);

        List<User> users = theQuery.getResultList();

        return users;
    }

    @Override
    public User getUser(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        User user = currentSession.get(User.class, theId);

        return user;
    }

    @Override
    public void saveUser(User theUser) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        currentSession.saveOrUpdate(theUser);
    }

    @Override
    public void deleteUser(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("DELETE FROM User WHERE id = :userId");
        theQuery.setParameter("userId", theId);

        theQuery.executeUpdate();
    }

    @Override
    public User getByUsernameAndPassword(String username, String password) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("FROM User WHERE username = :userUsername AND password = :userPassword");
        theQuery.setParameter("userUsername", username);
        theQuery.setParameter("userPassword", password);

        User user = (User) theQuery.uniqueResult();

        System.out.println("\n" + user + "\n");

        return user;
    }

    @Override
    public List<User> getUsersByRoleId(int theRoleId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("FROM User WHERE role.id = :roleId");
        theQuery.setParameter("roleId", theRoleId);

        List<User> users = theQuery.getResultList();

        return users;
    }

    @Override
    public List<User> getUsersByRoleName(String theRoleName) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("FROM User WHERE role.roleName = :roleNameParam");
        theQuery.setParameter("roleNameParam", theRoleName);

        List<User> users = theQuery.getResultList();

        return users;
    }
}
