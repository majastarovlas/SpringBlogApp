package com.springapp.repository.tag;

import com.springapp.entity.Tag;

import java.util.List;

public interface ITagRepository {

    List<Tag> getTags();

    Tag getTag(int theId);

    void saveTag(Tag theTag);

    void deleteTag(int theId);
}
