package com.springapp.repository.posttag;

import com.springapp.entity.PostTag;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PostTagRepositoryImpl implements IPostTagRepository {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public List<PostTag> getPostTags() {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query<PostTag> theQuery = currentSession.createQuery("FROM PostTag", PostTag.class);

        List<PostTag> postTags = theQuery.getResultList();

        return postTags;
    }

    @Override
    public PostTag getPostTag(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        PostTag postTag = currentSession.get(PostTag.class, theId);

        return postTag;
    }

    @Override
    public void savePostTag(PostTag thePostTag) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        currentSession.saveOrUpdate(thePostTag);
    }

    @Override
    public void deletePostTag(int theId) {

        Session currentSession = this.sessionFactory.getCurrentSession();

        Query theQuery = currentSession.createQuery("DELETE FROM PostTag WHERE id = :postTagId");
        theQuery.setParameter("postTagId", theId);

        theQuery.executeUpdate();
    }
}
